/*
Steve Diaz
CS 288 2017F Section 101
HW 01
*/

//CS 288-002 
#include <stdio.h>

int main(int argc, char *argv[]) {

char *cr;
int i;


printf("Argc Input & Address\n");
printf("+---------+---------+---------+---------+\n");
printf("|  %x       %08X                     |\n", argc, &argc);
printf("|---------|---------|---------|---------|\n");
printf("|%x  %08X                        |", argv, &argv);
printf("argv[%i]\n", i );
printf("|---------|---------|---------|---------|\n");
printf("\nargv going by characters with respective address\n");
	for(i = 1; i < argc; i++){

		cr = argv[i];

		while (*cr != '\0' ) {
			printf("|---------|---------|---------|---------|\n");
			printf("|     %c        %x     %08X          |",*cr, *cr, cr);
			printf("argv[%i]\n", i );
				cr = cr + sizeof(char);
		}

		printf("|---------|---------|---------|---------|\n");
		printf("|    \\0      %c           %x      %08X |\n",*cr, *cr, cr);
		printf("|---------------------------------------|\n");
	}

printf("+---------+---------+---------+---------+\n");
return 0;

}
